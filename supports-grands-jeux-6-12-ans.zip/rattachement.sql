-- Ressources de « Le Secret du Fort des Marées » : insertion seule, et seulement pour les fichiers déjà en ligne.
insert into public.activity_resources (activity_id,storage_path,title,page_count,description)
  select c.id,$v$games/fort-boyard-sportif/cartes-cles-et-indices.pdf$v$,$v$Cartes clés et cartes indices$v$,2,$v$20 cartes clés (16 et 4 de réserve) et les 20 cartes indices, 5 par équipage, à découper.$v$ from public.content_items c
  where c.slug = $v$fort-boyard-sportif$v$ and exists (select 1 from storage.objects o where o.bucket_id = 'activity-resources' and o.name = $v$games/fort-boyard-sportif/cartes-cles-et-indices.pdf$v$)
  on conflict do nothing;
insert into public.activity_resources (activity_id,storage_path,title,page_count,description)
  select c.id,$v$games/fort-boyard-sportif/carnet-du-sage.pdf$v$,$v$Carnet du Sage, cadenas et message$v$,5,$v$Les lots d’indices et les mots-code, 36 énigmes avec leurs réponses, l’affiche du cadenas à coller sur le coffre et le message de la capitaine.$v$ from public.content_items c
  where c.slug = $v$fort-boyard-sportif$v$ and exists (select 1 from storage.objects o where o.bucket_id = 'activity-resources' and o.name = $v$games/fort-boyard-sportif/carnet-du-sage.pdf$v$)
  on conflict do nothing;
-- Ressources de « L’Affaire de la Fête des Géants » : insertion seule, et seulement pour les fichiers déjà en ligne.
insert into public.activity_resources (activity_id,storage_path,title,page_count,description)
  select c.id,$v$games/l-affaire-de-la-fete-des-geants/fiches-personnages.pdf$v$,$v$Les 8 fiches personnages$v$,8,$v$Une page par personnage, à donner à son équipe : sa présentation, son secret et ce qu’il sait. La fiche de Charlie, le coupable, raconte ce qu’il a vraiment fait.$v$ from public.content_items c
  where c.slug = $v$l-affaire-de-la-fete-des-geants$v$ and exists (select 1 from storage.objects o where o.bucket_id = 'activity-resources' and o.name = $v$games/l-affaire-de-la-fete-des-geants/fiches-personnages.pdf$v$)
  on conflict do nothing;
insert into public.activity_resources (activity_id,storage_path,title,page_count,description)
  select c.id,$v$games/l-affaire-de-la-fete-des-geants/panneaux-tables.pdf$v$,$v$Panneaux des 8 tables$v$,4,$v$Un panneau par table : Bureau du comité, Garage, Kiosque, Boulangerie, Journal, Jardin municipal, Atelier de couture, Maison des porteurs.$v$ from public.content_items c
  where c.slug = $v$l-affaire-de-la-fete-des-geants$v$ and exists (select 1 from storage.objects o where o.bucket_id = 'activity-resources' and o.name = $v$games/l-affaire-de-la-fete-des-geants/panneaux-tables.pdf$v$)
  on conflict do nothing;
insert into public.activity_resources (activity_id,storage_path,title,page_count,description)
  select c.id,$v$games/l-affaire-de-la-fete-des-geants/feuille-enquete.pdf$v$,$v$Feuille d’enquête$v$,1,$v$Une par équipe : qui était où et qui le confirme, puis l’accusation (qui, comment, où, pourquoi, une preuve).$v$ from public.content_items c
  where c.slug = $v$l-affaire-de-la-fete-des-geants$v$ and exists (select 1 from storage.objects o where o.bucket_id = 'activity-resources' and o.name = $v$games/l-affaire-de-la-fete-des-geants/feuille-enquete.pdf$v$)
  on conflict do nothing;
insert into public.activity_resources (activity_id,storage_path,title,page_count,description)
  select c.id,$v$games/l-affaire-de-la-fete-des-geants/solution.pdf$v$,$v$Solution (pour les animateurs)$v$,2,$v$La solution, ce qui innocente chacun, qui sait quoi, et les textes à lire à la révélation.$v$ from public.content_items c
  where c.slug = $v$l-affaire-de-la-fete-des-geants$v$ and exists (select 1 from storage.objects o where o.bucket_id = 'activity-resources' and o.name = $v$games/l-affaire-de-la-fete-des-geants/solution.pdf$v$)
  on conflict do nothing;
insert into public.activity_resources (activity_id,storage_path,title,page_count,description)
  select c.id,$v$games/l-affaire-de-la-fete-des-geants/dame-capucine.pdf$v$,$v$Dame Capucine et ses 4 roues (facultatif)$v$,2,$v$L’affiche de la géante posée sur ses briques et les 4 roues à découper, à recoller tous ensemble à la fin.$v$ from public.content_items c
  where c.slug = $v$l-affaire-de-la-fete-des-geants$v$ and exists (select 1 from storage.objects o where o.bucket_id = 'activity-resources' and o.name = $v$games/l-affaire-de-la-fete-des-geants/dame-capucine.pdf$v$)
  on conflict do nothing;
-- Ressources de « L’Enquête de la Cloche d’Or » : insertion seule, et seulement pour les fichiers déjà en ligne.
insert into public.activity_resources (activity_id,storage_path,title,page_count,description)
  select c.id,$v$games/l-enquete-de-la-cloche-d-or/tableau-d-enquete.pdf$v$,$v$Le grand tableau d’enquête$v$,3,$v$Les 3 feuilles à assembler côte à côte : QUI ?, AVEC QUOI ?, OÙ ?, avec les 12 images.$v$ from public.content_items c
  where c.slug = $v$l-enquete-de-la-cloche-d-or$v$ and exists (select 1 from storage.objects o where o.bucket_id = 'activity-resources' and o.name = $v$games/l-enquete-de-la-cloche-d-or/tableau-d-enquete.pdf$v$)
  on conflict do nothing;
insert into public.activity_resources (activity_id,storage_path,title,page_count,description)
  select c.id,$v$games/l-enquete-de-la-cloche-d-or/cartes-ce-n-est-pas.pdf$v$,$v$Les 9 cartes « Ce n’est pas… » et le plan des enveloppes$v$,2,$v$Les cartes à glisser dans les enveloppes, et pour les adultes : quelle enveloppe à quel défi et à quelle manche, ce qui reste après chaque manche.$v$ from public.content_items c
  where c.slug = $v$l-enquete-de-la-cloche-d-or$v$ and exists (select 1 from storage.objects o where o.bucket_id = 'activity-resources' and o.name = $v$games/l-enquete-de-la-cloche-d-or/cartes-ce-n-est-pas.pdf$v$)
  on conflict do nothing;
insert into public.activity_resources (activity_id,storage_path,title,page_count,description)
  select c.id,$v$games/l-enquete-de-la-cloche-d-or/cartes-illustrees.pdf$v$,$v$Les 4 cartes des cachettes (A5)$v$,2,$v$La Fontaine, le Grand Chêne, le Manège et le Jardin des tournesols en grand, à coller sur les 4 cartons.$v$ from public.content_items c
  where c.slug = $v$l-enquete-de-la-cloche-d-or$v$ and exists (select 1 from storage.objects o where o.bucket_id = 'activity-resources' and o.name = $v$games/l-enquete-de-la-cloche-d-or/cartes-illustrees.pdf$v$)
  on conflict do nothing;
insert into public.activity_resources (activity_id,storage_path,title,page_count,description)
  select c.id,$v$games/l-enquete-de-la-cloche-d-or/poste-facteur.pdf$v$,$v$Tournée du facteur : étiquettes et lettres$v$,2,$v$Les étiquettes des 4 boîtes aux lettres, avec le déplacement de chaque animal, et les 16 lettres à découper.$v$ from public.content_items c
  where c.slug = $v$l-enquete-de-la-cloche-d-or$v$ and exists (select 1 from storage.objects o where o.bucket_id = 'activity-resources' and o.name = $v$games/l-enquete-de-la-cloche-d-or/poste-facteur.pdf$v$)
  on conflict do nothing;
-- Ressources de « L’Homme en noir : la chasse aux couleurs » : insertion seule, et seulement pour les fichiers déjà en ligne.
insert into public.activity_resources (activity_id,storage_path,title,page_count,description)
  select c.id,$v$games/l-homme-en-noir-chasse-aux-couleurs/grilles.pdf$v$,$v$Grilles de jeu (3 par page)$v$,1,$v$Une grille de 4 colonnes sur 10 lignes par enfant, avec un rappel des règles du comptage.$v$ from public.content_items c
  where c.slug = $v$l-homme-en-noir-chasse-aux-couleurs$v$ and exists (select 1 from storage.objects o where o.bucket_id = 'activity-resources' and o.name = $v$games/l-homme-en-noir-chasse-aux-couleurs/grilles.pdf$v$)
  on conflict do nothing;
-- Ressources de « La Bataille navale géante » : insertion seule, et seulement pour les fichiers déjà en ligne.
insert into public.activity_resources (activity_id,storage_path,title,page_count,description)
  select c.id,$v$games/la-bataille-navale-geante/grilles.pdf$v$,$v$Grilles de défense et d’attaque$v$,2,$v$Page 1 : la grille de défense, où le capitaine cache ses 5 bateaux. Page 2 : la grille d’attaque, où il note ses tirs. Une de chaque par équipe.$v$ from public.content_items c
  where c.slug = $v$la-bataille-navale-geante$v$ and exists (select 1 from storage.objects o where o.bucket_id = 'activity-resources' and o.name = $v$games/la-bataille-navale-geante/grilles.pdf$v$)
  on conflict do nothing;
insert into public.activity_resources (activity_id,storage_path,title,page_count,description)
  select c.id,$v$games/la-bataille-navale-geante/papiers-de-tir.pdf$v$,$v$Papiers de tir à découper$v$,1,$v$40 papiers par page, avec la case du tir et la réponse à entourer. À imprimer 3 ou 4 fois par équipe.$v$ from public.content_items c
  where c.slug = $v$la-bataille-navale-geante$v$ and exists (select 1 from storage.objects o where o.bucket_id = 'activity-resources' and o.name = $v$games/la-bataille-navale-geante/papiers-de-tir.pdf$v$)
  on conflict do nothing;
-- Ressources de « Le Brevet des Cinq Sens » : insertion seule, et seulement pour les fichiers déjà en ligne.
insert into public.activity_resources (activity_id,storage_path,title,page_count,description)
  select c.id,$v$games/le-brevet-des-cinq-sens/passeport.pdf$v$,$v$Passeport d’explorateur$v$,1,$v$Un par enfant, plié en deux : le prénom, un portrait à dessiner et les 5 cases à gommettes, une par sens.$v$ from public.content_items c
  where c.slug = $v$le-brevet-des-cinq-sens$v$ and exists (select 1 from storage.objects o where o.bucket_id = 'activity-resources' and o.name = $v$games/le-brevet-des-cinq-sens/passeport.pdf$v$)
  on conflict do nothing;
-- Ressources de « Le Carré magique » : insertion seule, et seulement pour les fichiers déjà en ligne.
insert into public.activity_resources (activity_id,storage_path,title,page_count,description)
  select c.id,$v$games/le-carre-magique/grilles-magiques.pdf$v$,$v$Grilles magiques (à afficher et pour la correction)$v$,4,$v$Une grille par page : grilles 1 et 2 en 3 × 3 pour les 6–7 ans, grilles 1 et 2 en 4 × 4 pour les 8–12 ans. À imprimer deux fois : une pour le mur, une pour la correction.$v$ from public.content_items c
  where c.slug = $v$le-carre-magique$v$ and exists (select 1 from storage.objects o where o.bucket_id = 'activity-resources' and o.name = $v$games/le-carre-magique/grilles-magiques.pdf$v$)
  on conflict do nothing;
insert into public.activity_resources (activity_id,storage_path,title,page_count,description)
  select c.id,$v$games/le-carre-magique/grilles-equipes.pdf$v$,$v$Grilles d’équipe vides$v$,2,$v$Page 1 : deux grilles 3 × 3 (6–7 ans). Page 2 : deux grilles 4 × 4 (8–12 ans). Avec le rappel des 6 symboles. Une grille par équipe et par manche.$v$ from public.content_items c
  where c.slug = $v$le-carre-magique$v$ and exists (select 1 from storage.objects o where o.bucket_id = 'activity-resources' and o.name = $v$games/le-carre-magique/grilles-equipes.pdf$v$)
  on conflict do nothing;
-- Ressources de « Le Festival des Compagnies » : insertion seule, et seulement pour les fichiers déjà en ligne.
insert into public.activity_resources (activity_id,storage_path,title,page_count,description)
  select c.id,$v$games/le-festival-des-compagnies/cartes-du-festival.pdf$v$,$v$Cartes du festival$v$,3,$v$Les 36 cartes ingrédients à découper : 12 Personnages, 12 Répliques et 12 Lieux, une page par sorte.$v$ from public.content_items c
  where c.slug = $v$le-festival-des-compagnies$v$ and exists (select 1 from storage.objects o where o.bucket_id = 'activity-resources' and o.name = $v$games/le-festival-des-compagnies/cartes-du-festival.pdf$v$)
  on conflict do nothing;
insert into public.activity_resources (activity_id,storage_path,title,page_count,description)
  select c.id,$v$games/le-festival-des-compagnies/story-board.pdf$v$,$v$Story-board$v$,1,$v$Le story-board en 3 cases (le début, le problème, la fin), à écrire ou à dessiner. Un par compagnie.$v$ from public.content_items c
  where c.slug = $v$le-festival-des-compagnies$v$ and exists (select 1 from storage.objects o where o.bucket_id = 'activity-resources' and o.name = $v$games/le-festival-des-compagnies/story-board.pdf$v$)
  on conflict do nothing;
-- Ressources de « Le Grand Pari des 80 jours » : insertion seule, et seulement pour les fichiers déjà en ligne.
insert into public.activity_resources (activity_id,storage_path,title,page_count,description)
  select c.id,$v$games/le-grand-pari-des-80-jours/fiches-escales.pdf$v$,$v$Fiches des 8 escales$v$,8,$v$Une page par escale : bonjour et compter, origine du jeu, matériel, règles, quand l’escale est réussie, coup de pouce, ce qu’on fait avant de partir.$v$ from public.content_items c
  where c.slug = $v$le-grand-pari-des-80-jours$v$ and exists (select 1 from storage.objects o where o.bucket_id = 'activity-resources' and o.name = $v$games/le-grand-pari-des-80-jours/fiches-escales.pdf$v$)
  on conflict do nothing;
insert into public.activity_resources (activity_id,storage_path,title,page_count,description)
  select c.id,$v$games/le-grand-pari-des-80-jours/passeport.pdf$v$,$v$Passeport d’équipe$v$,1,$v$Le rappel des règles et le carnet de route des 8 escales (réussie ou presque, jour d’arrivée). Un par équipe.$v$ from public.content_items c
  where c.slug = $v$le-grand-pari-des-80-jours$v$ and exists (select 1 from storage.objects o where o.bucket_id = 'activity-resources' and o.name = $v$games/le-grand-pari-des-80-jours/passeport.pdf$v$)
  on conflict do nothing;
insert into public.activity_resources (activity_id,storage_path,title,page_count,description)
  select c.id,$v$games/le-grand-pari-des-80-jours/calendrier-80-jours.pdf$v$,$v$Calendrier des 80 jours$v$,1,$v$Le compteur de jours : 3 bandes à coller (jours 0 à 89, avec les dates de 1872) où l’on pince sa pince à linge. Un par équipe.$v$ from public.content_items c
  where c.slug = $v$le-grand-pari-des-80-jours$v$ and exists (select 1 from storage.objects o where o.bucket_id = 'activity-resources' and o.name = $v$games/le-grand-pari-des-80-jours/calendrier-80-jours.pdf$v$)
  on conflict do nothing;
insert into public.activity_resources (activity_id,storage_path,title,page_count,description)
  select c.id,$v$games/le-grand-pari-des-80-jours/loteria.pdf$v$,$v$Lotería (Mexique)$v$,2,$v$Les 16 cartes du cantor et les 6 tablas de 9 images, avec les mots en espagnol.$v$ from public.content_items c
  where c.slug = $v$le-grand-pari-des-80-jours$v$ and exists (select 1 from storage.objects o where o.bucket_id = 'activity-resources' and o.name = $v$games/le-grand-pari-des-80-jours/loteria.pdf$v$)
  on conflict do nothing;
insert into public.activity_resources (activity_id,storage_path,title,page_count,description)
  select c.id,$v$games/le-grand-pari-des-80-jours/carte-du-monde.pdf$v$,$v$Carte du monde$v$,2,$v$Les 8 escales, la route vers l’est et la ligne de changement de date, pour le lancement et le final. 2 feuilles paysage à assembler.$v$ from public.content_items c
  where c.slug = $v$le-grand-pari-des-80-jours$v$ and exists (select 1 from storage.objects o where o.bucket_id = 'activity-resources' and o.name = $v$games/le-grand-pari-des-80-jours/carte-du-monde.pdf$v$)
  on conflict do nothing;
-- Ressources de « Le Jeu de Piste de la Carte Déchirée » : insertion seule, et seulement pour les fichiers déjà en ligne.
insert into public.activity_resources (activity_id,storage_path,title,page_count,description)
  select c.id,$v$games/le-jeu-de-piste-de-la-carte-dechiree/fiche-des-signes.pdf$v$,$v$Fiche des signes$v$,1,$v$Les 5 signes de piste expliqués, le secret du pisteur, les règles de sécurité et le signal d’urgence. Une par équipe, plus une pour le camp.$v$ from public.content_items c
  where c.slug = $v$le-jeu-de-piste-de-la-carte-dechiree$v$ and exists (select 1 from storage.objects o where o.bucket_id = 'activity-resources' and o.name = $v$games/le-jeu-de-piste-de-la-carte-dechiree/fiche-des-signes.pdf$v$)
  on conflict do nothing;
insert into public.activity_resources (activity_id,storage_path,title,page_count,description)
  select c.id,$v$games/le-jeu-de-piste-de-la-carte-dechiree/planches-signes.pdf$v$,$v$Planches de signes à découper$v$,12,$v$18 cartes-signes par équipe, à sa couleur et à sa forme : Départ, 12 flèches numérotées, Pause, Fin de piste, 2 Fausse piste et une flèche de réserve.$v$ from public.content_items c
  where c.slug = $v$le-jeu-de-piste-de-la-carte-dechiree$v$ and exists (select 1 from storage.objects o where o.bucket_id = 'activity-resources' and o.name = $v$games/le-jeu-de-piste-de-la-carte-dechiree/planches-signes.pdf$v$)
  on conflict do nothing;
insert into public.activity_resources (activity_id,storage_path,title,page_count,description)
  select c.id,$v$games/le-jeu-de-piste-de-la-carte-dechiree/carte-en-4-morceaux.pdf$v$,$v$Carte en 4 morceaux$v$,1,$v$Le cadre de la carte à compléter avec le plan du centre et la croix du coffre, à découper en 4.$v$ from public.content_items c
  where c.slug = $v$le-jeu-de-piste-de-la-carte-dechiree$v$ and exists (select 1 from storage.objects o where o.bucket_id = 'activity-resources' and o.name = $v$games/le-jeu-de-piste-de-la-carte-dechiree/carte-en-4-morceaux.pdf$v$)
  on conflict do nothing;
-- Ressources de « Le Mystère du Manoir » : insertion seule, et seulement pour les fichiers déjà en ligne.
insert into public.activity_resources (activity_id,storage_path,title,page_count,description)
  select c.id,$v$games/le-mystere-du-manoir/carnet_d_enquete_au_manoir_mysterieux.png$v$,$v$Carnet d’enquête$v$,1,$v$À imprimer pour chaque groupe afin de noter les suspects, les indices et l’accusation finale.$v$ from public.content_items c
  where c.slug = $v$le-mystere-du-manoir$v$ and exists (select 1 from storage.objects o where o.bucket_id = 'activity-resources' and o.name = $v$games/le-mystere-du-manoir/carnet_d_enquete_au_manoir_mysterieux.png$v$)
  on conflict do nothing;
insert into public.activity_resources (activity_id,storage_path,title,page_count,description)
  select c.id,$v$games/le-mystere-du-manoir/fiches_suspects_du_manoir_mysterieux.png$v$,$v$Fiches suspects$v$,1,$v$Présentation des quatre suspects du Manoir, à afficher pendant le lancement et sur les tables de témoignage.$v$ from public.content_items c
  where c.slug = $v$le-mystere-du-manoir$v$ and exists (select 1 from storage.objects o where o.bucket_id = 'activity-resources' and o.name = $v$games/le-mystere-du-manoir/fiches_suspects_du_manoir_mysterieux.png$v$)
  on conflict do nothing;
insert into public.activity_resources (activity_id,storage_path,title,page_count,description)
  select c.id,$v$games/le-mystere-du-manoir/temoignages.pdf$v$,$v$Témoignages écrits$v$,2,$v$Une page par table : le témoignage de Madame Violette et celui du Professeur Léonard, à lire à voix haute par les enquêteurs.$v$ from public.content_items c
  where c.slug = $v$le-mystere-du-manoir$v$ and exists (select 1 from storage.objects o where o.bucket_id = 'activity-resources' and o.name = $v$games/le-mystere-du-manoir/temoignages.pdf$v$)
  on conflict do nothing;
-- Ressources de « Le Village sous la Lune » : insertion seule, et seulement pour les fichiers déjà en ligne.
insert into public.activity_resources (activity_id,storage_path,title,page_count,description)
  select c.id,$v$games/le-village-sous-la-lune/cartes-roles.pdf$v$,$v$Cartes de rôles$v$,2,$v$Une série pour un village de 18 joueurs au plus : 3 loups-garous, la Voyante, la Sorcière et 13 villageois. À imprimer en recto seul, une série par village.$v$ from public.content_items c
  where c.slug = $v$le-village-sous-la-lune$v$ and exists (select 1 from storage.objects o where o.bucket_id = 'activity-resources' and o.name = $v$games/le-village-sous-la-lune/cartes-roles.pdf$v$)
  on conflict do nothing;
insert into public.activity_resources (activity_id,storage_path,title,page_count,description)
  select c.id,$v$games/le-village-sous-la-lune/fiche-meneur.pdf$v$,$v$Fiche du meneur$v$,1,$v$Le nombre de loups selon le nombre de joueurs, le texte de la nuit, le déroulement du jour et du vote.$v$ from public.content_items c
  where c.slug = $v$le-village-sous-la-lune$v$ and exists (select 1 from storage.objects o where o.bucket_id = 'activity-resources' and o.name = $v$games/le-village-sous-la-lune/fiche-meneur.pdf$v$)
  on conflict do nothing;
-- Ressources de « Les Douze Travaux d’Hercule » : insertion seule, et seulement pour les fichiers déjà en ligne.
insert into public.activity_resources (activity_id,storage_path,title,page_count,description)
  select c.id,$v$games/les-douze-travaux-d-hercule/fiches-travaux.pdf$v$,$v$Les 6 fiches-travaux$v$,6,$v$Une fiche par zone, à poser à l’entrée : le mythe, le défi, « Réussi quand », la sécurité, l’installation et le matériel.$v$ from public.content_items c
  where c.slug = $v$les-douze-travaux-d-hercule$v$ and exists (select 1 from storage.objects o where o.bucket_id = 'activity-resources' and o.name = $v$games/les-douze-travaux-d-hercule/fiches-travaux.pdf$v$)
  on conflict do nothing;
insert into public.activity_resources (activity_id,storage_path,title,page_count,description)
  select c.id,$v$games/les-douze-travaux-d-hercule/feuille-de-route.pdf$v$,$v$Feuille de route de l’équipe$v$,1,$v$Les 6 travaux et les 2 derniers, avec une case que l’animateur coche à chaque réussite. Une par équipe.$v$ from public.content_items c
  where c.slug = $v$les-douze-travaux-d-hercule$v$ and exists (select 1 from storage.objects o where o.bucket_id = 'activity-resources' and o.name = $v$games/les-douze-travaux-d-hercule/feuille-de-route.pdf$v$)
  on conflict do nothing;
-- Ressources de « Les Grandes Olympiades » : insertion seule, et seulement pour les fichiers déjà en ligne.
insert into public.activity_resources (activity_id,storage_path,title,page_count,description)
  select c.id,$v$games/olympiades/feuille-de-scores.pdf$v$,$v$Feuille de scores$v$,1,$v$Les 4 manches, le résultat de chaque équipe à chaque épreuve, les points (4, 3, 2, 1) et le total pour la cérémonie.$v$ from public.content_items c
  where c.slug = $v$olympiades$v$ and exists (select 1 from storage.objects o where o.bucket_id = 'activity-resources' and o.name = $v$games/olympiades/feuille-de-scores.pdf$v$)
  on conflict do nothing;
-- Ressources de « Le Sagamore des Deux Royaumes » : insertion seule, et seulement pour les fichiers déjà en ligne.
insert into public.activity_resources (activity_id,storage_path,title,page_count,description)
  select c.id,$v$games/sagamore/cartes-roles.pdf$v$,$v$Cartes rôle des deux équipes$v$,4,$v$24 cartes par équipe (2 Sorciers, 4 Sachems, 4 Espions, 4 Guerriers, 10 Sagamores, dont des cartes de rechange), avec qui bat qui sur chaque carte. À découper.$v$ from public.content_items c
  where c.slug = $v$sagamore$v$ and exists (select 1 from storage.objects o where o.bucket_id = 'activity-resources' and o.name = $v$games/sagamore/cartes-roles.pdf$v$)
  on conflict do nothing;
insert into public.activity_resources (activity_id,storage_path,title,page_count,description)
  select c.id,$v$games/sagamore/cartes-vie.pdf$v$,$v$Cartes vie$v$,4,$v$70 cartes vie par équipe (lune bleue ou soleil rouge), bord à bord. À découper, ou à remplacer par des jetons de deux couleurs.$v$ from public.content_items c
  where c.slug = $v$sagamore$v$ and exists (select 1 from storage.objects o where o.bucket_id = 'activity-resources' and o.name = $v$games/sagamore/cartes-vie.pdf$v$)
  on conflict do nothing;
